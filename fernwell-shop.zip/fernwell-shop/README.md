# Fernwell – demo plant shop

A static, single-page ecommerce demo (HTML, CSS, JavaScript). No build step.

## Deploy on Cloudflare Pages
1. Push this repo to GitHub.
2. In Cloudflare: Workers & Pages > Create > Pages > Connect to Git.
3. Select the repo, then use these settings:
   - Framework preset: None
   - Build command: (leave empty)
   - Build output directory: `/`
4. Click Save and Deploy.

Every push to `main` redeploys automatically.

## Notes
- Checkout is a demo: no payment is taken.
- Edit the `products` array in `index.html` to change the catalogue.
